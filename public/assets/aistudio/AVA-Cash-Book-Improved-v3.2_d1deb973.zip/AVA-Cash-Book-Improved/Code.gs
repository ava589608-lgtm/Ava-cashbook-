/**
 * AVA Cash Book — Google Sheets + Google Drive server
 * ---------------------------------------------------
 * Paste this whole file into Extensions > Apps Script of a NEW Google Sheet,
 * run `setup` once, then Deploy > New deployment > Web app.
 * Full steps are in the SETUP GUIDE.
 *
 * What it stores
 *   Sheet "Transactions"     one row per entry (soft-deleted rows stay, marked Deleted)
 *   Sheet "Monthly Summary"  rebuilt automatically after every sync
 *   Sheet "Category Summary" spending / income per month per category
 *   Sheet "Audit Log"        every create / edit / delete with device name
 *   Sheet "Cheques"          every cheque: to clear / cleared / returned / cancelled / missing numbers
 *   Sheet "Fleet"            vehicles with registration / insurance expiry and days left
 *   Sheet "Settings"         categories, vehicles, opening balances (JSON)
 *   Drive "AVA Cash Book"    Receipts/YYYY-MM/VAT | No VAT  + Backups (daily copy of this sheet)
 */

var SH_TX = 'Transactions';
var SH_SET = 'Settings';
var SH_LOG = 'Audit Log';
var SH_SUM = 'Monthly Summary';
var SH_CAT = 'Category Summary';
var SH_FLEET = 'Fleet';
var SH_CHQ = 'Cheques';
var ROOT_FOLDER = 'AVA Cash Book';
var KEEP_BACKUPS = 30;

var COLS = ['UID', 'Date', 'Ref', 'Account', 'Type', 'In (AED)', 'Out (AED)', 'VAT (AED)', 'Net of VAT (AED)',
  'Description', 'Party', 'Category', 'Sub-category', 'Vehicle', 'Transfer ID', 'Receipt', 'Receipt File ID',
  'Entered By', 'Created At', 'Updated At', 'Status', 'Rev',
  'Cheque No.', 'Cleared On', 'Voucher No.', 'Payment Method', 'Voucher Lines', 'Bank Key', 'Statement Text'];
var C = {}; COLS.forEach(function (n, i) { C[n] = i; });
var NCOL = COLS.length;
var ACC_NAME = { Bank: 'Bank Account', Petty: 'Petty Cash' };
var TEXT_COLS = ['UID', 'Ref', 'Transfer ID', 'Receipt File ID', 'Created At', 'Updated At', 'Cheque No.', 'Cleared On', 'Voucher No.', 'Voucher Lines', 'Bank Key'];
var MONEY_COLS = ['In (AED)', 'Out (AED)', 'VAT (AED)', 'Net of VAT (AED)'];

/* ============================ ONE-TIME SETUP ============================ */

function setup() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  ss.setSpreadsheetTimeZone(Session.getScriptTimeZone() || 'Asia/Dubai');

  var tx = sheet_(SH_TX, COLS);
  tx.setFrozenRows(1);
  var rows = Math.max(tx.getMaxRows() - 1, 1);
  TEXT_COLS.forEach(function (n) { tx.getRange(2, C[n] + 1, rows, 1).setNumberFormat('@'); });
  MONEY_COLS.forEach(function (n) { tx.getRange(2, C[n] + 1, rows, 1).setNumberFormat('#,##0.00'); });
  tx.getRange(2, C['Date'] + 1, rows, 1).setNumberFormat('yyyy-mm-dd');
  tx.getRange(2, C['Rev'] + 1, rows, 1).setNumberFormat('0');
  tx.hideColumns(C['UID'] + 1);
  tx.hideColumns(C['Receipt File ID'] + 1);
  tx.hideColumns(C['Rev'] + 1);
  header_(tx);
  tx.setColumnWidth(C['Description'] + 1, 240);

  sheet_(SH_LOG, ['Time', 'Entered By', 'Action', 'UID', 'Ref', 'Date', 'Account', 'Amount (AED)', 'Details']).setFrozenRows(1);
  var set = sheet_(SH_SET, ['Key', 'Value']);
  set.getRange('B:B').setNumberFormat('@');
  sheet_(SH_SUM, ['Month']);
  sheet_(SH_CAT, ['Month']);

  var def = ss.getSheetByName('Sheet1');
  if (def && def.getLastRow() === 0 && ss.getSheets().length > 1) ss.deleteSheet(def);

  var p = PropertiesService.getScriptProperties();
  if (!p.getProperty('API_KEY')) p.setProperty('API_KEY', makeKey_());
  rootFolder_();

  // daily backup copy of this spreadsheet into Drive / AVA Cash Book / Backups
  ScriptApp.getProjectTriggers().forEach(function (t) {
    if (t.getHandlerFunction() === 'dailyBackup') ScriptApp.deleteTrigger(t);
  });
  ScriptApp.newTrigger('dailyBackup').timeBased().everyDays(1).atHour(23).create();

  rebuildSummary();
  showKey();
}

function onOpen() {
  SpreadsheetApp.getUi().createMenu('AVA Cash Book')
    .addItem('Show connection key', 'showKey')
    .addItem('Rebuild summaries', 'rebuildSummary')
    .addItem('Back up now', 'dailyBackup')
    .addSeparator()
    .addItem('Make a new connection key (disconnects all phones)', 'resetKey')
    .addToUi();
}

function showKey() {
  var k = PropertiesService.getScriptProperties().getProperty('API_KEY');
  var msg = 'Connection key:\n\n' + k + '\n\nType this key in the app under Settings > Google connection, ' +
    'together with the Web App URL from Deploy > Manage deployments.';
  try { SpreadsheetApp.getUi().alert('AVA Cash Book', msg, SpreadsheetApp.getUi().ButtonSet.OK); }
  catch (e) { Logger.log(msg); }
}

function resetKey() {
  PropertiesService.getScriptProperties().setProperty('API_KEY', makeKey_());
  showKey();
}

/* ============================ WEB API ============================ */

function doGet() {
  return ContentService.createTextOutput('AVA Cash Book server is running. Open the app to use it.');
}

function doPost(e) {
  var out;
  try {
    if (!e || !e.postData || !e.postData.contents) throw new Error('empty_request');
    var req;
    try { req = JSON.parse(e.postData.contents); }
    catch (parseErr) { throw new Error('bad_json'); }
    if (!req || typeof req !== 'object') throw new Error('bad_json');
    var key = PropertiesService.getScriptProperties().getProperty('API_KEY');
    if (!key || req.key !== key) throw new Error('bad_key');
    var lock = LockService.getScriptLock();
    var gotLock = lock.tryLock(30000);
    if (!gotLock) throw new Error('server_busy');
    try {
      if (req.op === 'ping') {
        out = {
          ok: true,
          sheet: SpreadsheetApp.getActiveSpreadsheet().getName(),
          sheetUrl: SpreadsheetApp.getActiveSpreadsheet().getUrl(),
          folderUrl: rootFolder_().getUrl(),
          serverTime: Date.now()
        };
      } else if (req.op === 'sync') out = sync_(req);
      else if (req.op === 'receipt') out = receipt_(req);
      else throw new Error('unknown_op');
    } finally { lock.releaseLock(); }
  } catch (err) {
    var msg = String(err && err.message || err);
    // Map common errors to stable codes the app can show cleanly
    if (msg.indexOf('Service invoked too many times') !== -1) msg = 'quota_exceeded';
    if (msg.indexOf('Exceeded maximum execution time') !== -1) msg = 'timeout';
    if (msg.indexOf('Access denied') !== -1 || msg.indexOf('permission') !== -1) msg = 'permission_denied';
    out = { ok: false, error: msg };
  }
  return ContentService.createTextOutput(JSON.stringify(out)).setMimeType(ContentService.MimeType.JSON);
}

/* ---- sync: push local changes, then return everything changed since `since` ---- */
function sync_(req) {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var sh = ss.getSheetByName(SH_TX);
  if (!sh) throw new Error('run_setup_first');
  header_(sh);
  var tz = ss.getSpreadsheetTimeZone();
  var device = String(req.device || 'Unknown device').slice(0, 60);
  var now = Date.now();
  var records = req.records || [];
  var results = [];
  var changed = false;

  var last = sh.getLastRow();
  var data = last > 1 ? sh.getRange(2, 1, last - 1, NCOL).getValues() : [];
  var index = {};
  data.forEach(function (r, i) { if (r[C['UID']]) index[r[C['UID']]] = i; });

  var appends = [], logs = [];
  records.forEach(function (rec) {
    try {
      validate_(rec);
      var i = index[rec.uid];
      if (i !== undefined) {
        var cur = fromRow_(data[i], tz);
        if (cur.updatedAt > rec.updatedAt) { results.push({ uid: rec.uid, status: 'server_newer', record: cur }); return; }
        var row = toRow_(rec, now, device, cur);
        data[i] = row;
        sh.getRange(i + 2, 1, 1, NCOL).setValues([row]);
        formatRows_(sh, i + 2, 1);
        logs.push(logRow_(rec, device, rec.deleted && !cur.deleted ? 'Deleted' : 'Edited', diff_(cur, rec)));
      } else {
        var nrow = toRow_(rec, now, device, null);
        index[rec.uid] = data.length;
        data.push(nrow);
        appends.push(nrow);
        logs.push(logRow_(rec, device, rec.deleted ? 'Deleted' : 'Created', ''));
      }
      changed = true;
      results.push({ uid: rec.uid, status: 'ok', rev: now });
    } catch (err) {
      results.push({ uid: rec && rec.uid, status: 'error', error: String(err.message || err) });
    }
  });

  if (appends.length) {
    var start = sh.getLastRow() + 1;
    ensureRows_(sh, start + appends.length);
    sh.getRange(start, 1, appends.length, NCOL).setValues(appends);
    formatRows_(sh, start, appends.length);
  }
  if (logs.length) {
    var lg = ss.getSheetByName(SH_LOG);
    var ls = lg.getLastRow() + 1;
    ensureRows_(lg, ls + logs.length);
    lg.getRange(ls, 1, logs.length, logs[0].length).setValues(logs);
  }

  // settings (last write wins)
  var settings = readSettings_();
  if (req.settings && req.settings.updatedAt > (settings.updatedAt || 0)) {
    writeSettings_(req.settings);
    settings = req.settings;
    changed = true;
  }

  // pull changes since the client's last revision
  var since = Number(req.since) || 0;
  var changes = [];
  data.forEach(function (r) {
    if (r[C['UID']] && Number(r[C['Rev']]) >= since) changes.push(fromRow_(r, tz));
  });

  if (changed) { try { rebuildSummary(); } catch (e) { } try { writeCheques_(data, tz, settings); } catch (e) { } }
  return { ok: true, results: results, changes: changes, settings: settings, rev: Date.now(), total: data.length, sheetUrl: ss.getUrl() };
}

/* ---- receipt upload into Drive / AVA Cash Book / Receipts / YYYY-MM / VAT | No VAT ---- */
function receipt_(req) {
  if (!req.data) throw new Error('no_file');
  var month = String(req.date || '').slice(0, 7) || Utilities.formatDate(new Date(), 'Asia/Dubai', 'yyyy-MM');
  var folder = sub_(sub_(sub_(rootFolder_(), 'Receipts'), month), req.vat ? 'VAT' : 'No VAT');
  var ext = (String(req.name || '').match(/\.[A-Za-z0-9]{1,5}$/) || [''])[0] ||
    (req.mime === 'application/pdf' ? '.pdf' : '.jpg');
  var name = [req.date, req.ref, req.cat || 'Other', (Number(req.amount) || 0).toFixed(2)].join('_')
    .replace(/[^\w.\- ]+/g, '-') + ext;
  var blob = Utilities.newBlob(Utilities.base64Decode(req.data), req.mime || 'application/octet-stream', name);
  var f = folder.createFile(blob);
  f.setDescription('AVA Cash Book receipt for ' + req.ref + ' (' + req.uid + ')');
  return { ok: true, id: f.getId(), url: f.getUrl(), name: name };
}

/* ============================ ROW MAPPING ============================ */

function validate_(r) {
  if (!r || !r.uid) throw new Error('missing_uid');
  if (!/^\d{4}-\d{2}-\d{2}$/.test(r.date)) throw new Error('bad_date');
  if (r.acc !== 'Bank' && r.acc !== 'Petty') throw new Error('bad_account');
  if (r.type !== 'in' && r.type !== 'out') throw new Error('bad_type');
  if (!(Number(r.amt) >= 0) || Math.round(r.amt) !== Number(r.amt)) throw new Error('bad_amount');
}

function toRow_(r, rev, device, cur) {
  var a = r.amt / 100, v = (r.vat || 0) / 100;
  var row = new Array(NCOL);
  row[C['UID']] = r.uid;
  row[C['Date']] = r.date;
  row[C['Ref']] = r.ref || '';
  row[C['Account']] = ACC_NAME[r.acc];
  row[C['Type']] = r.type === 'in' ? 'In' : 'Out';
  row[C['In (AED)']] = r.type === 'in' ? a : '';
  row[C['Out (AED)']] = r.type === 'out' ? a : '';
  row[C['VAT (AED)']] = v || '';
  row[C['Net of VAT (AED)']] = Math.round(r.amt - (r.vat || 0)) / 100;
  row[C['Description']] = r.desc || '';
  row[C['Party']] = r.party || '';
  row[C['Category']] = r.cat || '';
  row[C['Sub-category']] = r.sub || '';
  row[C['Vehicle']] = r.veh || '';
  row[C['Transfer ID']] = r.tr || '';
  row[C['Receipt']] = r.rcpt && r.rcpt.url || '';
  row[C['Receipt File ID']] = r.rcpt && r.rcpt.id || '';
  row[C['Entered By']] = cur ? (cur.by || device) : (r.by || device);
  row[C['Created At']] = new Date(r.createdAt || rev).toISOString();
  row[C['Updated At']] = new Date(r.updatedAt || rev).toISOString();
  row[C['Status']] = r.deleted ? 'Deleted' : 'Active';
  row[C['Rev']] = rev;
  row[C['Cheque No.']] = r.chq || '';
  row[C['Cleared On']] = r.clr || '';
  row[C['Voucher No.']] = r.pv || '';
  row[C['Payment Method']] = r.pm || '';
  row[C['Voucher Lines']] = r.lines && r.lines.length ? JSON.stringify(r.lines) : '';
  row[C['Bank Key']] = r.bk || '';
  row[C['Statement Text']] = r.sd || '';
  return row;
}

function fromRow_(r, tz) {
  var d = r[C['Date']];
  if (d instanceof Date) d = Utilities.formatDate(d, tz, 'yyyy-MM-dd');
  var type = String(r[C['Type']]).toLowerCase() === 'in' ? 'in' : 'out';
  var amt = Math.round(Number(type === 'in' ? r[C['In (AED)']] : r[C['Out (AED)']]) * 100) || 0;
  var acc = String(r[C['Account']]).indexOf('Petty') >= 0 ? 'Petty' : 'Bank';
  var url = String(r[C['Receipt']] || ''), fid = String(r[C['Receipt File ID']] || '');
  return {
    uid: String(r[C['UID']]), date: String(d), ref: String(r[C['Ref']] || ''), acc: acc, type: type, amt: amt,
    vat: Math.round(Number(r[C['VAT (AED)']] || 0) * 100) || 0,
    desc: String(r[C['Description']] || ''), party: String(r[C['Party']] || ''),
    cat: String(r[C['Category']] || ''), sub: String(r[C['Sub-category']] || ''), veh: String(r[C['Vehicle']] || ''),
    tr: String(r[C['Transfer ID']] || ''),
    rcpt: url || fid ? { id: fid, url: url } : null,
    by: String(r[C['Entered By']] || ''),
    createdAt: ts_(r[C['Created At']]), updatedAt: ts_(r[C['Updated At']]),
    deleted: String(r[C['Status']]) === 'Deleted', rev: Number(r[C['Rev']]) || 0,
    chq: str_(r[C['Cheque No.']]), clr: dstr_(r[C['Cleared On']], tz), pv: str_(r[C['Voucher No.']]), pm: str_(r[C['Payment Method']]),
    lines: lines_(r[C['Voucher Lines']]), bk: str_(r[C['Bank Key']]), sd: str_(r[C['Statement Text']])
  };
}

function str_(v) { return v == null ? '' : String(v); }
function dstr_(v, tz) { return v instanceof Date ? Utilities.formatDate(v, tz, 'yyyy-MM-dd') : str_(v); }
function lines_(v) { if (!v) return null; try { return JSON.parse(v); } catch (e) { return null; } }
function header_(sh) {
  // add the v3 columns to sheets made by older versions
  var h = sh.getRange(1, 1, 1, NCOL).getValues()[0];
  if (h[NCOL - 1] !== COLS[NCOL - 1]) {
    ensureCols_(sh, NCOL);
    sh.getRange(1, 1, 1, NCOL).setValues([COLS]).setFontWeight('bold').setBackground('#0b3d3a').setFontColor('#ffffff');
    var rows = Math.max(sh.getMaxRows() - 1, 1);
    TEXT_COLS.forEach(function (n) { sh.getRange(2, C[n] + 1, rows, 1).setNumberFormat('@'); });
    sh.hideColumns(C['Voucher Lines'] + 1); sh.hideColumns(C['Bank Key'] + 1);
  }
}
function ensureCols_(sh, n) { var m = sh.getMaxColumns ? sh.getMaxColumns() : n; if (n > m) sh.insertColumnsAfter(m, n - m); }

function ts_(v) { return v instanceof Date ? v.getTime() : (Date.parse(v) || 0); }

function diff_(a, b) {
  var f = ['date', 'acc', 'type', 'amt', 'vat', 'desc', 'party', 'cat', 'sub', 'veh', 'ref'], out = [];
  f.forEach(function (k) {
    var x = a[k] == null ? '' : a[k], y = b[k] == null ? '' : b[k];
    if (String(x) !== String(y)) {
      if (k === 'amt' || k === 'vat') { x = (x / 100).toFixed(2); y = (y / 100).toFixed(2); }
      out.push(k + ': ' + x + ' → ' + y);
    }
  });
  if ((a.rcpt && a.rcpt.id || '') !== (b.rcpt && b.rcpt.id || '')) out.push('receipt changed');
  return out.join('; ');
}

function logRow_(r, device, action, details) {
  return [new Date().toISOString(), device, action, r.uid, r.ref || '', r.date, ACC_NAME[r.acc] || r.acc,
    (r.type === 'out' ? -1 : 1) * r.amt / 100, details || (r.desc || '')];
}

/* ============================ SUMMARIES ============================ */

function rebuildSummary() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var sh = ss.getSheetByName(SH_TX); if (!sh) return;
  var tz = ss.getSpreadsheetTimeZone();
  var last = sh.getLastRow();
  var rows = last > 1 ? sh.getRange(2, 1, last - 1, NCOL).getValues() : [];
  var m = {}, cat = {};
  rows.forEach(function (r) {
    if (!r[C['UID']]) return;
    var x = fromRow_(r, tz);
    if (x.deleted) return;
    var k = x.date.slice(0, 7);
    var s = m[k] || (m[k] = { bi: 0, bo: 0, pi: 0, po: 0, ti: 0, to: 0, vi: 0, vo: 0 });
    var pre = x.acc === 'Bank' ? 'b' : 'p';
    s[pre + (x.type === 'in' ? 'i' : 'o')] += x.amt;
    if (!x.tr) {
      s[x.type === 'in' ? 'ti' : 'to'] += x.amt;
      s[x.type === 'in' ? 'vi' : 'vo'] += x.vat;
      var ck = k + '|' + (x.type === 'in' ? 'Income' : 'Expense') + '|' + (x.cat || 'Uncategorised');
      cat[ck] = (cat[ck] || 0) + x.amt;
    }
  });
  var head = ['Month', 'Bank In', 'Bank Out', 'Petty In', 'Petty Out', 'Income', 'Expenses', 'Net Profit',
    'VAT Collected', 'VAT Paid', 'VAT Payable'];
  var out = Object.keys(m).sort().map(function (k) {
    var s = m[k];
    return [k, s.bi, s.bo, s.pi, s.po, s.ti, s.to, s.ti - s.to, s.vi, s.vo, s.vi - s.vo].map(function (v, i) { return i ? v / 100 : "'" + v; });
  });
  writeTable_(ss.getSheetByName(SH_SUM) || ss.insertSheet(SH_SUM), head, out, 2);

  var cout = Object.keys(cat).sort().map(function (k) { var p = k.split('|'); return ["'" + p[0], p[1], p[2], cat[k] / 100]; });
  writeTable_(ss.getSheetByName(SH_CAT) || ss.insertSheet(SH_CAT), ['Month', 'Type', 'Category', 'Amount (AED)'], cout, 4);
}

function writeTable_(sh, head, rows, moneyFrom) {
  sh.clearContents();
  sh.getRange(1, 1, 1, head.length).setValues([head]).setFontWeight('bold').setBackground('#0b3d3a').setFontColor('#ffffff');
  sh.setFrozenRows(1);
  if (rows.length) {
    ensureRows_(sh, rows.length + 1);
    sh.getRange(2, 1, rows.length, head.length).setValues(rows);
    sh.getRange(2, moneyFrom, rows.length, head.length - moneyFrom + 1).setNumberFormat('#,##0.00');
  }
}

/* ============================ BACKUP ============================ */

function dailyBackup() {
  refreshFleet();
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var folder = sub_(rootFolder_(), 'Backups');
  var name = ss.getName() + ' backup ' + Utilities.formatDate(new Date(), ss.getSpreadsheetTimeZone(), 'yyyy-MM-dd HHmm');
  DriveApp.getFileById(ss.getId()).makeCopy(name, folder);
  var files = [], it = folder.getFiles();
  while (it.hasNext()) files.push(it.next());
  files.sort(function (a, b) { return b.getDateCreated() - a.getDateCreated(); });
  files.slice(KEEP_BACKUPS).forEach(function (f) { f.setTrashed(true); });
}

/* ============================ HELPERS ============================ */

function onEdit(e) {
  // Manual edits in the Transactions sheet are picked up by every phone on its next sync.
  try {
    var sh = e.range.getSheet();
    if (sh.getName() !== SH_TX || e.range.getRow() < 2) return;
    var col = e.range.getColumn();
    if (col === C['Rev'] + 1 || col === C['Updated At'] + 1) return;
    var n = e.range.getNumRows(), now = new Date(), iso = [], rev = [];
    for (var i = 0; i < n; i++) { iso.push([now.toISOString()]); rev.push([now.getTime()]); }
    sh.getRange(e.range.getRow(), C['Updated At'] + 1, n, 1).setValues(iso);
    sh.getRange(e.range.getRow(), C['Rev'] + 1, n, 1).setValues(rev);
  } catch (err) { }
}

function sheet_(name, head) {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var sh = ss.getSheetByName(name) || ss.insertSheet(name);
  if (sh.getLastRow() === 0) {
    sh.getRange(1, 1, 1, head.length).setValues([head]).setFontWeight('bold')
      .setBackground('#0b3d3a').setFontColor('#ffffff');
  }
  return sh;
}

function formatRows_(sh, start, n) {
  TEXT_COLS.forEach(function (c) { sh.getRange(start, C[c] + 1, n, 1).setNumberFormat('@'); });
  MONEY_COLS.forEach(function (c) { sh.getRange(start, C[c] + 1, n, 1).setNumberFormat('#,##0.00'); });
  sh.getRange(start, C['Date'] + 1, n, 1).setNumberFormat('yyyy-mm-dd');
}

function ensureRows_(sh, needed) {
  var max = sh.getMaxRows();
  if (needed > max) sh.insertRowsAfter(max, needed - max + 200);
}

function readSettings_() {
  var sh = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(SH_SET);
  if (!sh || sh.getLastRow() < 2) return {};
  var v = sh.getRange(2, 1, sh.getLastRow() - 1, 2).getValues();
  for (var i = 0; i < v.length; i++) if (v[i][0] === 'settings') { try { return JSON.parse(v[i][1]); } catch (e) { } }
  return {};
}

function writeSettings_(obj) {
  var sh = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(SH_SET);
  sh.getRange(2, 1, 2, 2).setValues([
    ['settings', JSON.stringify(obj)],
    ['updated', new Date(obj.updatedAt || Date.now()).toISOString()]
  ]);
  try { writeFleet_(obj); } catch (e) { }
}

/* Fleet register sheet (rebuilt from the app's vehicle list on every settings change) */
function writeFleet_(obj) {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var sh = ss.getSheetByName(SH_FLEET) || ss.insertSheet(SH_FLEET);
  var head = ['Bus Number / Plate No.', 'Owner', 'Vehicle Type', 'Model', 'Seat Capacity',
    'Registration Expiry', 'Days Left (Reg)', 'Insurance Expiry', 'Days Left (Ins)', 'Status'];
  var info = obj.vinfo || {}, tz = ss.getSpreadsheetTimeZone();
  var todayStr = Utilities.formatDate(new Date(), tz, 'yyyy-MM-dd'), t0 = Date.parse(todayStr + 'T00:00:00Z');
  var days = function (d) { return d ? Math.round((Date.parse(d + 'T00:00:00Z') - t0) / 864e5) : ''; };
  var rows = (obj.veh || []).map(function (p) {
    var v = info[p] || {}, dr = days(v.reg), di = days(v.ins);
    var worst = Math.min(dr === '' ? 1e9 : dr, di === '' ? 1e9 : di);
    var st = worst < 0 ? 'EXPIRED' : worst <= 30 ? 'Renew soon' : worst === 1e9 ? 'No dates' : 'OK';
    return [p, v.owner || '', v.vtype || '', v.model || '', v.seats || '', v.reg || '', dr, v.ins || '', di, st];
  });
  sh.clearContents();
  sh.getRange(1, 1, 1, head.length).setValues([head]).setFontWeight('bold').setBackground('#0b3d3a').setFontColor('#ffffff');
  sh.setFrozenRows(1);
  if (rows.length) {
    ensureRows_(sh, rows.length + 1);
    sh.getRange(2, 1, rows.length, head.length).setValues(rows);
    sh.getRange(2, 6, rows.length, 1).setNumberFormat('dd-mm-yyyy');
    sh.getRange(2, 8, rows.length, 1).setNumberFormat('dd-mm-yyyy');
    var bg = rows.map(function (r) { var c = r[9] === 'EXPIRED' ? '#f8d7cf' : r[9] === 'Renew soon' ? '#f6e7c4' : '#ffffff'; return head.map(function () { return c; }); });
    sh.getRange(2, 1, rows.length, head.length).setBackgrounds(bg);
  }
}

/* Cheque register sheet: every cheque with status, plus missing numbers */
function writeCheques_(data, tz, settings) {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var sh = ss.getSheetByName(SH_CHQ) || ss.insertSheet(SH_CHQ);
  var all = data.filter(function (r) { return r[C['UID']]; }).map(function (r) { return fromRow_(r, tz); }).filter(function (x) { return !x.deleted; });
  var ret = {}; all.forEach(function (x) { if (x.acc === 'Bank' && x.type === 'in' && x.chq) ret[x.chq] = 1; });
  var X = (settings && settings.chqX) || {}, seen = {};
  var rows = all.filter(function (x) { return x.acc === 'Bank' && x.type === 'out' && x.chq; }).map(function (x) {
    seen[x.chq] = 1;
    var st = ret[x.chq] ? 'Returned' : x.clr ? 'Cleared' : 'To clear';
    return ["'" + x.chq, x.date, x.pv, x.party, x.desc, x.cat, x.amt / 100, st, x.clr];
  });
  Object.keys(X).forEach(function (n) { seen[n] = 1; rows.push(["'" + n, X[n].date || '', '', '', X[n].note || 'Cancelled', '', '', 'Cancelled', '']); });
  var nums = Object.keys(seen).map(Number).filter(function (n) { return n > 0; });
  if (nums.length) {
    var mn = Math.min.apply(null, nums), mx = Math.max.apply(null, nums);
    if (mx - mn < 3000) for (var i = mn; i <= mx; i++) { var k = ('000000' + i).slice(-6); if (!seen[k]) rows.push(["'" + k, '', '', '', 'Not in books – check the cheque stub', '', '', 'MISSING', '']); }
  }
  rows.sort(function (a, b) { return a[0] < b[0] ? -1 : 1; });
  var head = ['Cheque No.', 'Written', 'Voucher', 'Payee', 'Details', 'Category', 'Amount (AED)', 'Status', 'Cleared On'];
  sh.clearContents();
  sh.getRange(1, 1, 1, head.length).setValues([head]).setFontWeight('bold').setBackground('#0b3d3a').setFontColor('#ffffff');
  sh.setFrozenRows(1);
  if (rows.length) {
    ensureRows_(sh, rows.length + 1);
    sh.getRange(2, 1, rows.length, head.length).setValues(rows);
    sh.getRange(2, 7, rows.length, 1).setNumberFormat('#,##0.00');
    sh.getRange(2, 1, rows.length, head.length).setBackgrounds(rows.map(function (r) {
      var c = r[7] === 'To clear' ? '#f6e7c4' : r[7] === 'MISSING' ? '#f8d7cf' : r[7] === 'Cancelled' || r[7] === 'Returned' ? '#eeeeee' : '#ffffff';
      return head.map(function () { return c; });
    }));
  }
}

/* Re-run daily so "Days Left" stays current */
function refreshFleet() { try { writeFleet_(readSettings_()); } catch (e) { } }

function rootFolder_() {
  var p = PropertiesService.getScriptProperties(), id = p.getProperty('ROOT_ID');
  if (id) { try { var f = DriveApp.getFolderById(id); if (!f.isTrashed()) return f; } catch (e) { } }
  var it = DriveApp.getFoldersByName(ROOT_FOLDER);
  var folder = it.hasNext() ? it.next() : DriveApp.createFolder(ROOT_FOLDER);
  p.setProperty('ROOT_ID', folder.getId());
  return folder;
}

function sub_(parent, name) {
  var it = parent.getFoldersByName(name);
  return it.hasNext() ? it.next() : parent.createFolder(name);
}

function makeKey_() {
  return Utilities.getUuid().replace(/-/g, '').slice(0, 24).toUpperCase().replace(/(.{4})/g, '$1-').slice(0, 29);
}
