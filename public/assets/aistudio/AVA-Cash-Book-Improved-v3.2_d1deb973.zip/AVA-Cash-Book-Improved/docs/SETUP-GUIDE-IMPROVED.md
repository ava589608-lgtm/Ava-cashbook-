# AVA Cash Book v3.2 – Improved Setup Guide

**Time needed:** 15–20 minutes (one-time)

---

## What you get

| Location              | What is stored                                      |
|-----------------------|-----------------------------------------------------|
| Phone (offline)       | All entries + receipt photos                        |
| Google Sheet          | Transactions, Summaries, Audit Log, Cheques, Fleet  |
| Google Drive          | Receipts by month + daily backups (last 30 kept)    |

---

## Step 1 – Create the Google Sheet (5 min)

1. Go to https://sheets.google.com → create a **Blank spreadsheet**
2. Name it exactly: **AVA Cash Book**
3. Click **Extensions → Apps Script**
4. Delete any code that is already there
5. Open the file `Code.gs` from this package → select all → copy → paste into the Apps Script editor
6. Click the **Save** (disk) icon
7. At the top toolbar, choose the function **`setup`** → click **Run**
8. Authorize:
   - Review permissions → choose your Google account
   - Advanced → Go to AVA Cash Book (unsafe) → Allow
9. Go back to the Sheet. You will see a new menu called **AVA Cash Book**
10. Click **AVA Cash Book → Show connection key** and write the key down safely

> Tip: Use a dedicated Google account for the business, not your personal one.

---

## Step 2 – Publish the server (2 min)

1. In the Apps Script editor click **Deploy → New deployment**
2. Click the gear icon → select **Web app**
3. Settings:
   - Description: `AVA Cash Book Production`
   - Execute as: **Me**
   - Who has access: **Anyone**
4. Click **Deploy**
5. Copy the **Web app URL** (it ends with `/exec`)

---

## Step 3 – Host the phone app (5 min)

### Recommended: Netlify Drop (no coding needed)

1. Go to https://app.netlify.com/drop
2. Drag the entire **`app`** folder onto the page
3. You will receive a link like `https://something.netlify.app`
4. Create a free Netlify account so the site stays online permanently
5. (Optional) Change the site name to something nice (e.g. `ava-cashbook`)

Alternative: GitHub Pages if you already use GitHub.

> Important: Never open the `index.html` file directly from the phone’s file manager. It must be served over HTTPS.

---

## Step 4 – Install on each phone (1 min)

1. Open the Netlify link in **Chrome** (Android) or **Safari** (iPhone)
2. Install the app:
   - Android: menu ⋮ → **Install app** or **Add to Home screen**
   - iPhone: Share button → **Add to Home Screen**
3. Open the installed **AVA Cash** app
4. Go to **Settings → Connect Google Sheets & Drive**
5. Paste:
   - Web App URL
   - Connection Key
6. Give this phone a clear name (example: `Office`, `Driver Ahmed`, `Accountant`)
7. Tap **Test & connect**

The status pill at the top right will show:
- 🟢 Synced
- 🟡 Waiting
- ⚪ Offline
- 🔴 Problem (tap to see the error)

---

## Step 5 – Load starting data (once)

1. In the app go to **Settings → Restore or import a backup**
2. Select the file `AVA-starting-data-Oct-2026.json`
3. Confirm

This loads:
- Opening Bank balance: AED 50,418.86
- August–September bank statement lines
- October payment vouchers / cheques

---

## Updating the app later

**Frontend only (categories, new features, UI):**
- Replace the files inside the `app` folder on Netlify / GitHub Pages
- Open the app twice on each phone (it will update automatically)

**Backend (Code.gs):**
1. Paste the new Code.gs into Apps Script → Save
2. Deploy → Manage deployments → Edit (pencil) → Version: **New version** → Deploy
3. The URL stays the same

---

## Security checklist after setup

- [ ] Dedicated Google account used
- [ ] 2-Step Verification turned on
- [ ] Connection key stored only in a password manager
- [ ] Every phone has a PIN set
- [ ] First full backup downloaded and saved outside Google
