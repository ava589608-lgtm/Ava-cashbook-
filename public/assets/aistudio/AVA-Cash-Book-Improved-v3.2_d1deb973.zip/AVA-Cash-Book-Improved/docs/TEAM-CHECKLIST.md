# AVA Cash Book – Daily & Monthly Checklist

**Print this and keep near the office desk / in the WhatsApp group.**

---

## Daily (every working day)

- [ ] Enter all cash and bank movements the same day they happen
- [ ] Attach a photo of the tax invoice for every VAT expense
- [ ] Choose the correct **Vehicle** on Diesel and Maintenance entries
- [ ] Check the green/yellow/red sync pill on every phone
- [ ] Look at the **Needs attention** list on the Home screen and clear items

## Weekly

- [ ] Import the bank statement (Cheques tab → Import bank statement)
- [ ] Mark cleared cheques
- [ ] Review any “MISSING” cheque numbers and mark cancelled if needed
- [ ] Check registration / insurance expiry alerts on the Home screen

## Month-end (do on the 1st or 2nd of the new month)

1. Make sure every entry for the previous month is entered and synced
2. Import the final bank statement for the month
3. Go to **Settings → Close the books on or before** → set the last day of the previous month
4. Download a full backup: **Settings → Download backup** → save the JSON file outside Google (external drive or another cloud)
5. Optionally download the Google Sheet as Excel (File → Download → Microsoft Excel)

## Security rules (never break these)

- Never share the **Connection Key** in WhatsApp, email or paper
- Every phone must have a PIN set
- Use a dedicated Google account for the business (not personal)
- Turn on 2-Step Verification on that Google account
- If a phone is lost → immediately go to the Sheet → AVA Cash Book → Make a new connection key

## Who does what

| Task                        | Responsible          |
|----------------------------|----------------------|
| Daily entries (drivers)    | Drivers / Supervisors |
| Daily entries (office)     | Office staff         |
| Bank statement import      | Accountant / Owner   |
| Month-end close + backup   | Owner / Accountant   |
| Adding new vehicles        | Owner                |
| Changing categories        | Owner                |

---

**Remember:** The app works offline. Entries are safe on the phone even without internet. They will sync automatically when the phone is online again.

## Status pill meanings

| Pill / banner | Meaning |
|---------------|---------|
| Synced | Everything is in Google Sheets |
| X waiting | Saved on phone, sending soon |
| Offline · X waiting | No internet — entries are safe on the phone |
| Sync problem | Tap the pill to see the error and retry |

## Quick-entry presets

On the Home screen, the round chips under Money in / Money out are **quick presets**.
Tap one to open a new entry with the category already filled (Diesel, Salary, Rent, etc.).
