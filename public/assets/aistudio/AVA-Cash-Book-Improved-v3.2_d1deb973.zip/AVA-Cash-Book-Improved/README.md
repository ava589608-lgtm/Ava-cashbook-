# AVA Cash Book v3.2 – Improved Package (Multi-user)

Ready-to-deploy package for **AVA PASSENGERS TRANSPORT BY RENTAL BUSES LLC**.

## Folder structure

```
AVA-Cash-Book-Improved/
├── Code.gs                          ← Paste into Google Apps Script
├── AVA-starting-data-Oct-2026.json  ← Import once after first connection
├── app/                             ← Upload this whole folder to Netlify / GitHub Pages
│   ├── index.html
│   ├── sw.js
│   ├── manifest.webmanifest
│   └── icons/
└── docs/
    ├── SETUP-GUIDE-IMPROVED.md      ← Follow this to create the system
    └── TEAM-CHECKLIST.md            ← Print and give to the team
```

## Quick start

1. Follow **docs/SETUP-GUIDE-IMPROVED.md**
2. After connecting the first phone, import the starting data JSON
3. On each phone set the correct **Device role** (Settings → Device role)
4. Print **docs/TEAM-CHECKLIST.md** and put it on the wall

## Company configuration

- **Company name:** AVA PASSENGERS TRANSPORT BY RENTAL BUSES LLC
- **Address on vouchers:** P.O. Box 91977, Dubai, UAE | Phone: 00971 4 3439666 | Email: Contact@avarental.ae
- **Voucher titles (automatic):**
  - Rent category or description → **RENT PAYMENT VOUCHER**
  - Salary category or description → **SALARY SLIP**
  - Everything else → **PAYMENT VOUCHER**
- **Opening Bank balance:** AED 50,418.86
- **Vehicles:** 10 buses/vans (Sharjah + Dubai plates)
- **Transactions included:** 57 entries (Aug–Oct 2026)

## Multi-user roles (per device)

Set the role on each phone under **Settings → Device role**:

| Role | What they can do |
|------|------------------|
| **Admin** | Full access – Bank + Petty, vouchers, reports, settings, delete |
| **Check** | View only – can see Bank + Petty + reports, cannot add or edit anything |
| **Staff** | Petty Cash only – can add and view Petty Cash transactions only |

- Role is stored **only on that phone** (not synced to Google).
- Change it any time in Settings.
- Staff cannot see Bank balance or Bank transactions.
- Check role is perfect for the accountant / owner who only wants to monitor.

## Long-term tips

- Download a full JSON backup every month-end and keep it outside Google
- Never share the Connection Key
- Use a dedicated Google account + 2FA
- Review the “Needs attention” list on the Home screen every day
- Set Admin role only on trusted phones (owner / main accountant)
